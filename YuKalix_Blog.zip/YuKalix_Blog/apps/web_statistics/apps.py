from django.apps import AppConfig


class WebStatisticsConfig(AppConfig):
    name = 'web_statistics'
